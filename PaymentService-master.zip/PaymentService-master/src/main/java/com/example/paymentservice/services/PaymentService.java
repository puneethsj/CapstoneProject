package com.example.paymentservice.services;

public interface PaymentService {
    String initiatePayment();
}
