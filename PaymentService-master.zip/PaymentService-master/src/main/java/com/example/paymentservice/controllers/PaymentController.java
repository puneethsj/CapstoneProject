package com.example.paymentservice.controllers;

import com.example.paymentservice.services.PaymentService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class PaymentController {

    PaymentService paymentService;
    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @PostMapping("/service")
    public String initiatePayment() {
        return paymentService.initiatePayment();
    }
}
