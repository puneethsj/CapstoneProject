package com.example.paymentservice.services;

public interface PaymentGatewaySelector {
    PaymentGateway get();
}
