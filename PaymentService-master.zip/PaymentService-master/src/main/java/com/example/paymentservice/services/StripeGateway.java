package com.example.paymentservice.services;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

@Service
@Primary
public class StripeGateway implements PaymentGateway{
    @Override
    public String generatePaymentLink() {
        return "";
    }
}
