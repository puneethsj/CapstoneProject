package com.example.userservicecapstone.dtos;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class LoginResponseDto {
    private String tokenValue;
}
